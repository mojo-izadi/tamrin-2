import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;

public class MainMenu {
    private final User user;
    private final Scanner scanner;

    public MainMenu(User user, Scanner scanner) {
        this.user = user;
        this.scanner = scanner;
        mainMenu();
    }

    private void mainMenu() {
        String command;
        while (true) {
            command = scanner.nextLine();
            Matcher matcher;
            if ((matcher = MatcherScanner.getCommandMatcher(command, "^new_game ([^ ]+)$")).find())
                newGame(matcher);
            else if (command.matches("list_users"))
                Main.listUsers();
            else if (command.matches("scoreboard"))
                scoreboard();
            else if (command.matches("logout")) {
                System.out.println("logout successful");
                break;
            } else if (command.matches("shop")) {
                Shop shop = new Shop(user, scanner);
                shop.shopMenu();
            } else if (command.matches("help"))
                System.out.println("new_game [username]\n" +
                        "scoreboard\n" +
                        "list_users\n" +
                        "shop\n" +
                        "help\n" +
                        "logout");
            else
                System.out.println("invalid command");
        }
    }

    private void scoreboard() {
        printUsersInDesiredOrder(User.getUsers());
    }

    private void printUsersInDesiredOrder(ArrayList<User> users) {
        ArrayList<User> usersCopy = (ArrayList<User>) users.clone();
        int indexOfNextUser;
        while (usersCopy.size() != 1) {
            indexOfNextUser = 0;
            User nextUser = new User();
            for (int index = 0; index < usersCopy.size(); index++) {
                if (nextUser.getScore() != usersCopy.get(index).getScore()) {
                    if (nextUser.getScore() < usersCopy.get(index).getScore()) {
                        nextUser = usersCopy.get(index);
                        indexOfNextUser = index;
                    }
                } else if (nextUser.getWins() != usersCopy.get(index).getWins()) {
                    if (nextUser.getWins() < usersCopy.get(index).getWins()) {
                        nextUser = usersCopy.get(index);
                        indexOfNextUser = index;
                    }
                } else if (nextUser.getDraws() != usersCopy.get(index).getDraws()) {
                    if (nextUser.getDraws() < usersCopy.get(index).getDraws()) {
                        nextUser = usersCopy.get(index);
                        indexOfNextUser = index;
                    }
                } else if (nextUser.getLosses() != usersCopy.get(index).getLosses()) {
                    if (nextUser.getLosses() > usersCopy.get(index).getLosses()) {
                        nextUser = usersCopy.get(index);
                        indexOfNextUser = index;
                    }
                } else {
                    if (nextUser.getUsername().compareTo(usersCopy.get(index).getUsername()) > 0) {
                        nextUser = usersCopy.get(index);
                        indexOfNextUser = index;
                    }
                }
            }
            printUser(nextUser);
            usersCopy.remove(indexOfNextUser);
        }
        printUser(usersCopy.get(0));
    }

    private void printUser(User user) {
        String username = user.getUsername();
        int score = user.getScore();
        int wins = user.getWins();
        int draws = user.getDraws();
        int losses = user.getLosses();
        System.out.println(username + " " + score + " " + wins + " " + draws + " " + losses);
    }


    private void newGame(Matcher matcher) {
        String username = matcher.group(1);
        if (!username.matches("\\w+"))
            System.out.println("username format is invalid");
        else if (user.getUsername().compareTo(username) == 0)
            System.out.println("you must choose another player to start a game");
        else if (!User.usernameIsTaken(username))
            System.out.println("no user exists with this username");
        else {
            System.out.println("new game started successfully between " + user.getUsername() + " and " + username);
            User opponent = User.getUserByUsername(username);
            gameMenu(user, opponent, scanner);
        }
    }

    private void gameMenu(User home, User away, Scanner scanner) {
        Cell[][] homeBoard = new Cell[10][10];
        Cell[][] awayBoard = new Cell[10][10];
        new BoardSetter(home, homeBoard, scanner);
        new BoardSetter(away, awayBoard, scanner);
        while (true) {
            makeTurn(home, away, homeBoard, awayBoard, scanner);
            if (gameOver(home, away, homeBoard, awayBoard))
                break;
            makeTurn(away, home, awayBoard, homeBoard, scanner);
            if (gameOver(home, away, homeBoard, awayBoard))
                break;
        }
    }

    private void makeTurn(User user, User enemy, Cell[][] homeBoard, Cell[][] awayBoard, Scanner scanner) {
        Matcher matcher;
        String command;
        boolean bombNotThrown = true;
        boolean playerForfeited = false;
        while (bombNotThrown && enemy.arsenal.allShipsNotDestroyed()) {
            command = scanner.nextLine();
            if ((matcher = MatcherScanner.getCommandMatcher(command, "^bomb ([0-9]+),([0-9]+)$")).find())
                bombNotThrown = throwBomb(matcher, homeBoard, awayBoard, user, enemy);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^put-airplane ([0-9]+),([0-9]+) ([A-Za-z-]{2})$")).find())
                putAirplaneOrder(matcher, user, enemy, awayBoard, homeBoard);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^scanner ([0-9]+),([0-9]+)")).find())
                scannerOrder(matcher, user, awayBoard);
            else if (command.matches("show-turn"))
                System.out.println(user.getUsername() + "'s turn");
            else if (command.matches("show-my-board")) {
                user.arsenal.destroyShipsIfBombed();
                BoardPrinter.printOwnBoard(homeBoard);
            } else if (command.matches("forfeit")) {
                playerForfeited = isForfeit(user);
                break;
            } else if (command.matches("show-rival-board")) {
                enemy.arsenal.destroyShipsIfBombed();
                BoardPrinter.printRivalBoard(awayBoard);
            } else if (command.matches("help"))
                System.out.println("bomb [x],[y]\n" +
                        "put-airplane [x],[y] [-h|-v]\n" +
                        "scanner [x],[y]\n" +
                        "show-turn\n" +
                        "show-my-board\n" +
                        "show-rival-board\n" +
                        "help\n" +
                        "forfeit");
            else
                System.out.println("invalid command");
        }
        if (!playerForfeited && enemy.arsenal.allShipsNotDestroyed())
            System.out.println("turn completed");
    }

    private void putAirplaneOrder(Matcher matcher, User user, User enemy, Cell[][] board, Cell[][] ownBoard) {
        int xCoordinate = Integer.parseInt(matcher.group(1));
        int yCoordinate = Integer.parseInt(matcher.group(2));
        String direction = matcher.group(3);
        if (xCoordinate > 10 || xCoordinate < 1 ||
                yCoordinate > 10 || yCoordinate < 1)
            System.out.println("wrong coordination");
        else if (!direction.matches("-v") && !direction.matches("-h"))
            System.out.println("invalid direction");
        else if (airplaneIsOffTheBoard(direction, xCoordinate, yCoordinate))
            System.out.println("off the board");
        else if (user.arsenal.doesNotHaveProduct("airplane"))
            System.out.println("you don't have airplane");
        else if (airplaneRangeContainsAntiaircraft(xCoordinate, yCoordinate, direction, board, enemy) != null) {
            user.arsenal.changeWeaponCount("airplane", -1);
            System.out.println("the rival's antiaircraft destroyed your airplane");
            neutralizeAntiaircraft(airplaneRangeContainsAntiaircraft(xCoordinate, yCoordinate, direction, board, enemy));
        } else {
            user.arsenal.changeWeaponCount("airplane", -1);
            destroyCells(xCoordinate, yCoordinate, direction, board, ownBoard);
        }
    }

    private void destroyCells(int xCoordinate, int yCoordinate, String direction, Cell[][] board, Cell[][] ownBoard) {
        int shipsDestroyed = 0;
        Cell cell, cellOnOwnBoard;
        if ("-v".equals(direction)) {
            for (int i = xCoordinate; i < xCoordinate + 2; i++) {
                for (int j = yCoordinate; j < yCoordinate + 5; j++) {
                    cell = board[i - 1][j - 1];
                    cellOnOwnBoard = ownBoard[i - 1][j - 1];
                    shipsDestroyed += cellHitWithAirplane(cell, cellOnOwnBoard);
                }
            }
        } else {
            for (int i = xCoordinate; i < xCoordinate + 5; i++) {
                for (int j = yCoordinate; j < yCoordinate + 2; j++) {
                    cell = board[i - 1][j - 1];
                    cellOnOwnBoard = ownBoard[i - 1][j - 1];
                    shipsDestroyed += cellHitWithAirplane(cell, cellOnOwnBoard);
                }
            }
        }
        if (shipsDestroyed == 0)
            System.out.println("target not found");
        else
            System.out.println(shipsDestroyed + " pieces of rival's ships was damaged");
    }

    private int cellHitWithAirplane(Cell cell, Cell cellOnOwnBoard) {
        if (cell.containsState(State.BOMBED))
            return 0;
        else if (cell.containsShip()) {
            cell.addState(State.BOMBED);
            return 1;
        } else if (cell.containsState(State.MINE)) {
            cell.addState(State.BOMBED);
            cellOnOwnBoard.addState(State.BOMBED);
            return 0;
        }
        cell.addState(State.BOMBED);
        return 0;
    }

    private void neutralizeAntiaircraft(Cell[] antiaircraft) {
        for (Cell cell : antiaircraft) {
            cell.removeState(State.ANTIAIRCRAFT);
        }
        user.arsenal.removeAntiaircraft(antiaircraft);
    }

    private Cell[] airplaneRangeContainsAntiaircraft(int xCoordinate, int yCoordinate, String direction, Cell[][] board, User enemy) {
        if ("-v".equals(direction)) {
            for (int i = xCoordinate; i < xCoordinate + 1; i++) {
                for (int j = yCoordinate; j < yCoordinate + 4; j++) {
                    if (board[i][j].containsState(State.ANTIAIRCRAFT))
                        return enemy.arsenal.getFirstContainingAntiaircraft(i, j);
                }
            }
            return null;
        }
        for (int i = xCoordinate; i < xCoordinate + 4; i++) {
            for (int j = yCoordinate; j < yCoordinate + 1; j++) {
                if (board[i][j].containsState(State.ANTIAIRCRAFT))
                    return enemy.arsenal.getFirstContainingAntiaircraft(i, j);
            }
        }
        return null;
    }

    private boolean airplaneIsOffTheBoard(String direction, int xCoordinate, int yCoordinate) {
        if ("-v".equals(direction)) {
            return 5 + yCoordinate > 11 || 2 + xCoordinate > 11;
        }
        return 5 + xCoordinate > 11 || 2 + yCoordinate > 11;
    }

    private static boolean isForfeit(User user) {
        user.setHasForfeited(true);
        return true;
    }

    private void scannerOrder(Matcher matcher, User user, Cell[][] board) {
        int xCoordinate = Integer.parseInt(matcher.group(1));
        int yCoordinate = Integer.parseInt(matcher.group(2));
        if (xCoordinate > 10 || xCoordinate < 1 ||
                yCoordinate > 10 || yCoordinate < 1)
            System.out.println("wrong coordination");
        else if (xCoordinate > 8 || yCoordinate > 8)
            System.out.println("off the board");
        else if (user.arsenal.doesNotHaveProduct("scanner"))
            System.out.println("you don't have scanner");
        else {
            user.arsenal.changeWeaponCount("scanner", -1);
            scanBoard(board, xCoordinate, yCoordinate);
        }
    }

    private void scanBoard(Cell[][] board, int xCoordinate, int yCoordinate) {
        for (int i = yCoordinate; i < yCoordinate + 3; i++) {
            for (int j = xCoordinate; j < xCoordinate + 3; j++) {
                System.out.print("|" + board[j - 1][i - 1].toStringForScanner());
            }
            System.out.println("|");
        }
    }

    private boolean throwBomb(Matcher matcher, Cell[][] homeBoard, Cell[][] awayBoard, User user, User enemy) {
        int xCoordinate = Integer.parseInt(matcher.group(1));
        int yCoordinate = Integer.parseInt(matcher.group(2));
        if (xCoordinate > 10 || xCoordinate < 1 ||
                yCoordinate > 10 || yCoordinate < 1) {
            System.out.println("wrong coordination");
            return true;
        }
        Cell cellToBomb = awayBoard[xCoordinate - 1][yCoordinate - 1];
        Cell correspondingCellInOwnBoard = homeBoard[xCoordinate - 1][yCoordinate - 1];
        if (cellToBomb.containsState(State.BOMBED)) {
            System.out.println("this place has already destroyed");
            return true;
        } else if (cellToBomb.containsShip()) {
            shipHit(cellToBomb, enemy);
            return true;
        } else if (cellToBomb.containsState(State.MINE)) {
            rivalMineHit(cellToBomb, correspondingCellInOwnBoard, user);
            return false;
        } else {
            cellToBomb.addState(State.BOMBED);
            System.out.println("the bomb fell into sea");
            return false;
        }
    }

    private void rivalMineHit(Cell cellToBomb, Cell correspondingCellInOwnBoard, User user) {
        System.out.println("you destroyed the rival's mine");
        cellToBomb.addState(State.BOMBED);
        correspondingCellInOwnBoard.addState(State.BOMBED);
        user.arsenal.changeWeaponCount("mine", -1);
    }

    private void shipHit(Cell cell, User user) {
        cell.addState(State.BOMBED);
        Ship ship = user.arsenal.getShipContainingCell(cell);
        if (ship.isDestroyed())
            System.out.println("the rival's ship" + ship.getLength() + " was destroyed");
        else
            System.out.println("the rival's ship was damaged");
    }

    private boolean gameOver(User home, User away, Cell[][] homeBoard, Cell[][] awayBoard) {
        boolean homePlayerAlive = home.arsenal.allShipsNotDestroyed();
        boolean awayPlayerAlive = away.arsenal.allShipsNotDestroyed();
        int homePlayerScore = calculateScore(awayBoard);
        int awayPlayerScore = calculateScore(homeBoard);
        if (!homePlayerAlive && !awayPlayerAlive) {
            System.out.println("draw");
            draw(home, away, homePlayerScore, awayPlayerScore);
            return true;
        } else if (!homePlayerAlive) {
            System.out.println(away.getUsername() + " is winner");
            win(away, home, awayPlayerScore, homePlayerScore);
            return true;
        } else if (!awayPlayerAlive) {
            System.out.println(home.getUsername() + " is winner");
            win(home, away, homePlayerScore, awayPlayerScore);
            return true;
        } else if (home.hasForfeited()) {
            System.out.println(home.getUsername() + " is forfeited");
            System.out.println(away.getUsername() + " is winner");
            forfeit(away, home, awayPlayerScore, homePlayerScore);
            return true;
        } else if (away.hasForfeited()) {
            System.out.println(away.getUsername() + " is forfeited");
            System.out.println(home.getUsername() + " is winner");
            forfeit(home, away, homePlayerScore, awayPlayerScore);
            return true;
        } else
            return false;
    }

    private int calculateScore(Cell[][] board) {
        int score = 0;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                Cell cell = board[i][j];
                if (cell.containsState(State.BOMBED) && cell.containsShip())
                    score++;
                else if (cell.containsState(State.BOMBED) && cell.containsState(State.MINE))
                    score--;
            }
        }
        return score;
    }

    private void forfeit(User winner, User loser, int winnerScore, int loserScore) {
        winner.gameFinished("win by forfeit", winnerScore);
        loser.gameFinished("forfeit", loserScore);
    }

    private void win(User winner, User loser, int winnerScore, int loserScore) {
        winner.gameFinished("win", winnerScore);
        loser.gameFinished("lose", loserScore);
    }

    private void draw(User user1, User user2, int user1Score, int user2Score) {
        user1.gameFinished("draw", user1Score);
        user2.gameFinished("draw", user2Score);
    }
}
