import java.util.*;
import java.util.regex.*;


public class Main {

    public static void main(String[] args) {
        signupMenu();
    }

    private static void signupMenu() {
        Scanner scanner = new Scanner(System.in);
        Matcher matcher;
        String command;
        while (true) {
            command = scanner.nextLine();
            if ((matcher = MatcherScanner.getCommandMatcher(command, "^register ([^ ]+) ([^ ]+)$")).find())
                register(matcher);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^login ([^ ]+) ([^ ]+)$")).find())
                login(matcher, scanner);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^remove ([^ ]+) ([^ ]+)$")).find())
                removeUser(matcher);
            else if (command.matches("list_users"))
                listUsers();
            else if (command.matches("exit")) {
                System.out.println("program ended");
                break;
            } else if (command.matches("help"))
                System.out.println("register [username] [password]\n" +
                        "login [username] [password]\n" +
                        "remove [username] [password]\n" +
                        "list_users\n" +
                        "help\n" +
                        "exit");
            else
                System.out.println("invalid command");
        }
    }

    public static void listUsers() {
        ArrayList<String> usernames = new ArrayList<>();
        for (User user : User.getUsers()) {
            usernames.add(user.getUsername());
        }
        printInAsciiOrder(usernames);
    }

    private static void register(Matcher matcher) {
        String username = matcher.group(1);
        String password = matcher.group(2);
        if (!username.matches("\\w+"))
            System.out.println("username format is invalid");
        else if (!password.matches("\\w+"))
            System.out.println("password format is invalid");
        else if (User.usernameIsTaken(username))
            System.out.println("a user exists with this username");
        else {
            System.out.println("register successful");
            new User(username, password);
        }
    }

    private static void login(Matcher matcher, Scanner scanner) {
        String username = matcher.group(1);
        String password = matcher.group(2);
        if (!username.matches("\\w+"))
            System.out.println("username format is invalid");
        else if (!password.matches("\\w+"))
            System.out.println("password format is invalid");
        else if (!User.usernameIsTaken(username))
            System.out.println("no user exists with this username");
        else if (User.getUserByUsername(username).getPassword().compareTo(password) != 0)
            System.out.println("incorrect password");
        else {
            System.out.println("login successful");
            new MainMenu(User.getUserByUsername(username), scanner);
        }
    }


    private static void removeUser(Matcher matcher) {
        String username = matcher.group(1);
        String password = matcher.group(2);
        if (!username.matches("\\w+"))
            System.out.println("username format is invalid");
        else if (!password.matches("\\w+"))
            System.out.println("password format is invalid");
        else if (!User.usernameIsTaken(username))
            System.out.println("no user exists with this username");
        else if (User.getUserByUsername(username).getPassword().compareTo(password) != 0)
            System.out.println("incorrect password");
        else {
            System.out.println("removed " + username + " successfully");
            User.getUserByUsername(username).deleteUser();
        }
    }

    private static void printInAsciiOrder(ArrayList<String> words) {
        ArrayList<String> wordsCopy = (ArrayList<String>) words.clone();
        int indexOfNextWord;
        while (wordsCopy.size() != 1) {
            indexOfNextWord = 0;
            String nextWord = "~";
            for (int index = 0; index < wordsCopy.size(); index++) {
                if (nextWord.compareTo(wordsCopy.get(index)) > 0) {
                    nextWord = wordsCopy.get(index);
                    indexOfNextWord = index;
                }
            }
            System.out.println(nextWord);
            wordsCopy.remove(indexOfNextWord);
        }
        System.out.println(wordsCopy.get(0));
    }

}