import java.util.Scanner;
import java.util.regex.Matcher;

public class BoardSetter {
    private final User user;
    private final Cell[][] board;
    private final Scanner scanner;

    public BoardSetter(User user, Cell[][] board, Scanner scanner) {
        this.user = user;
        this.board = board;
        this.scanner = scanner;
        setBoard();
    }

    public void setBoard() {
        String command;
        Matcher matcher;
        initializeBoard(board);
        while (true) {
            command = scanner.nextLine();
            if ((matcher = MatcherScanner.getCommandMatcher(command, "^put S([0-9]+) ([0-9]+),([0-9]+) (-[A-Za-z])$")).find())
                placeShipCommand(matcher);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^put-mine ([0-9]+),([0-9]+)$")).find())
                putMine(matcher);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^put-antiaircraft ([0-9]+) (-[A-Za-z])$")).find())
                putAntiaircraftOrder(matcher);
            else if ((matcher = MatcherScanner.getCommandMatcher(command, "^invisible ([0-9]+),([0-9]+)")).find())
                invisible(matcher);
            else if (command.matches("finish-arranging")) {
                if (arrangingFinished()) {
                    System.out.println("turn completed");
                    break;
                } else
                    System.out.println("you must put all ships on the board");
            } else if (command.matches("show-my-board"))
                BoardPrinter.printOwnBoard(board);
            else if (command.matches("help"))
                System.out.println("put S[number] [x],[y] [-h|-v]\n" +
                        "put-mine [x],[y]\n" +
                        "put-antiaircraft [s] [-h|-v]\n" +
                        "invisible [x],[y]\n" +
                        "show-my-board\n" +
                        "help\n" +
                        "finish-arranging");
            else
                System.out.println("invalid command");
        }
    }

    private static void initializeBoard(Cell[][] board) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                board[i][j] = new Cell(j, i);
            }
        }
    }

    private void placeAntiaircraft(String direction, int firstRowOrColumn, Cell[][] board, User user) {
        Cell[] antiaircraft = user.arsenal.addAntiaircraftToBoard();
        if (direction.compareTo("-h") == 0) {
            for (int i = 0; i < 10; i++) {
                for (int j = firstRowOrColumn; j < firstRowOrColumn + 3; j++) {
                    board[i][j - 1].addState(State.ANTIAIRCRAFT);
                    antiaircraft[10 * (j - firstRowOrColumn) + i] = board[i][j - 1];
                }
            }
        } else {
            for (int j = 0; j < 10; j++) {
                for (int i = firstRowOrColumn; i < firstRowOrColumn + 3; i++) {
                    board[i - 1][j].addState(State.ANTIAIRCRAFT);
                    antiaircraft[10 * (i - firstRowOrColumn) + j] = board[i - 1][j];
                }
            }
        }
    }


    private void putMine(Matcher matcher) {
        int xCoordinate = Integer.parseInt(matcher.group(1));
        int yCoordinate = Integer.parseInt(matcher.group(2));
        if (xCoordinate > 10 || xCoordinate < 1 ||
                yCoordinate > 10 || yCoordinate < 1)
            System.out.println("wrong coordination");
        else if (user.arsenal.doesNotHaveProduct("mine"))
            System.out.println("you don't have enough mine");
        else if (cellsContainShipOrMine(1, "-h", xCoordinate, yCoordinate))
            System.out.println("collision with the other ship or mine on the board");
        else {
            board[xCoordinate - 1][yCoordinate - 1].addState(State.MINE);
            user.arsenal.changeWeaponCount("mine", -1);
        }
    }

    private void placeShipCommand(Matcher matcher) {
        int shipLength = Integer.parseInt(matcher.group(1));
        int xCoordinate = Integer.parseInt(matcher.group(2));
        int yCoordinate = Integer.parseInt(matcher.group(3));
        String direction = matcher.group(4);
        if (shipLength > 4 || shipLength < 1)
            System.out.println("invalid ship number");
        else if (xCoordinate > 10 || xCoordinate < 1 ||
                yCoordinate > 10 || yCoordinate < 1)
            System.out.println("wrong coordination");
        else if (!direction.matches("-v") && !direction.matches("-h"))
            System.out.println("invalid direction");
        else if (isOffTheBoard(shipLength, direction, xCoordinate, yCoordinate))
            System.out.println("off the board");
        else if (!user.hasShipToPlace(shipLength))
            System.out.println("you don't have this type of ship");
        else if (cellsContainShipOrMine(shipLength, direction, xCoordinate, yCoordinate))
            System.out.println("collision with the other ship or mine on the board");
        else
            placeShip(shipLength, direction, xCoordinate, yCoordinate);
    }

    private void placeShip(int length, String direction, int xCoordinate, int yCoordinate) {
        user.arsenal.placeShip(length, direction, xCoordinate, yCoordinate, board);
    }

    private boolean cellsContainShipOrMine(int length, String direction, int xCoordinate,
                                           int yCoordinate) {
        if ("-v".equals(direction)) {
            for (int i = 0; i < length; i++) {
                if (board[xCoordinate - 1][yCoordinate - 1 + i].cannotPlaceShipOrMine())
                    return true;
            }
        } else {
            for (int i = 0; i < length; i++) {
                if (board[xCoordinate - 1 + i][yCoordinate - 1].cannotPlaceShipOrMine())
                    return true;
            }
        }
        return false;
    }

    private void invisible(Matcher matcher) {
        int xCoordinate = Integer.parseInt(matcher.group(1));
        int yCoordinate = Integer.parseInt(matcher.group(2));
        if (xCoordinate > 10 || xCoordinate < 1 ||
                yCoordinate > 10 || yCoordinate < 1)
            System.out.println("wrong coordination");
        else if (user.arsenal.doesNotHaveProduct("invisible"))
            System.out.println("you don't have enough invisible");
        else if (!board[xCoordinate - 1][yCoordinate - 1].containsShip())
            System.out.println("there is no ship on this place on the board");
        else if (board[xCoordinate - 1][yCoordinate - 1].containsState(State.INVISIBLE))
            System.out.println("this place has already made invisible");
        else {
            board[xCoordinate - 1][yCoordinate - 1].addState(State.INVISIBLE);
            user.arsenal.changeWeaponCount("invisible", -1);
        }
    }

    private void putAntiaircraftOrder(Matcher matcher) {
        int firstRowOrColumn = Integer.parseInt(matcher.group(1));
        String direction = matcher.group(2);
        if (firstRowOrColumn > 10 || firstRowOrColumn < 1)
            System.out.println("wrong coordination");
        else if (isOffTheBoard(3, direction, firstRowOrColumn, firstRowOrColumn))
            System.out.println("off the board");
        else if (!direction.matches("-v") && !direction.matches("-h"))
            System.out.println("invalid direction");
        else if (user.arsenal.doesNotHaveProduct("antiaircraft"))
            System.out.println("you don't have enough antiaircraft");
        else {
            placeAntiaircraft(direction, firstRowOrColumn, board, user);
            user.arsenal.changeWeaponCount("antiaircraft", -1);
        }
    }

    private boolean isOffTheBoard(int length, String direction, int xCoordinate, int yCoordinate) {
        if ("-v".equals(direction)) {
            return length + yCoordinate > 11;
        }
        return length + xCoordinate > 11;
    }

    private boolean arrangingFinished() {
        for (int i = 1; i < 5; i++) {
            if (user.hasShipToPlace(i))
                return false;
        }
        return true;
    }

}
