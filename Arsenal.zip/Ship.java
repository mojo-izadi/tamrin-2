import java.util.ArrayList;

public class Ship {
    private final int length;
    private final ArrayList<Cell> ship = new ArrayList<>();
    private State stateOfCells;

    public Ship(int length) {
        this.length = length;
        switch (length) {
            case 1:
                stateOfCells = State.SHIP_WITH_LENGTH_1;
                break;
            case 2:
                stateOfCells = State.SHIP_WITH_LENGTH_2;
                break;
            case 3:
                stateOfCells = State.SHIP_WITH_LENGTH_3;
                break;
            case 4:
                stateOfCells = State.SHIP_WITH_LENGTH_4;
                break;
        }
    }

    public int getLength() {
        return length;
    }

    public void addCell(Cell cell) {
        this.ship.add(cell);
        cell.addState(stateOfCells);
    }

    public boolean isDestroyed() {
        for (Cell cell : ship) {
            if (!cell.containsState(State.BOMBED))
                return false;
        }
        for (Cell cell : ship) {
            cell.addState(State.DESTROYED_SHIP);
        }
        return true;
    }

    public boolean containsCell(Cell cell) {
        return ship.contains(cell);
    }

}
