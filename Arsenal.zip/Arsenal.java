import java.util.HashMap;
import java.util.Map;

public class Arsenal {
    private int mineCount;
    private int antiaircraftCount;
    private int airplaneCount;
    private int scannerCount;
    private int invisibleCount;
    private final HashMap<Ship, Boolean> ships = new HashMap<>();
    private final HashMap<Cell[], Boolean> antiaircrafts;

    public Arsenal() {
        mineCount = 0;
        antiaircraftCount = 0;
        airplaneCount = 0;
        scannerCount = 0;
        invisibleCount = 0;
        this.resetShips();
        antiaircrafts = new HashMap<>();
    }

    public void resetShips() {
        for (int i = 1; i <= 4; i++) {
            for (int j = 0; j <= 4 - i; j++)
                ships.put(new Ship(i), false);
        }
    }

    public boolean doesNotHaveProduct(String product) {
        switch (product) {
            case "mine":
                return this.mineCount <= 0;
            case "antiaircraft":
                return this.antiaircraftCount <= 0;
            case "airplane":
                return this.airplaneCount <= 0;
            case "scanner":
                return this.scannerCount <= 0;
            case "invisible":
                return this.invisibleCount <= 0;
        }
        return true;
    }

    public boolean hasShipToPlace(int length) {
        for (Map.Entry<Ship, Boolean> shipBooleanEntry : ships.entrySet()) {
            if (!shipBooleanEntry.getValue() && shipBooleanEntry.getKey().getLength() == length)
                return true;
        }
        return false;
    }

    public void placeShip(int length, String direction, int xCoordinate, int yCoordinate, Cell[][] board) {
        Ship ship = null;
        for (Map.Entry<Ship, Boolean> shipBooleanEntry : ships.entrySet()) {
            ship = shipBooleanEntry.getKey();
            if (!shipBooleanEntry.getValue() && shipBooleanEntry.getKey().getLength() == length) {
                shipBooleanEntry.setValue(true);
                break;
            }
        }
        if ("-v".equals(direction)) {
            for (int i = 0; i < length; i++) {
                ship.addCell(board[xCoordinate - 1][yCoordinate - 1 + i]);
            }
        } else {
            for (int i = 0; i < length; i++) {
                ship.addCell(board[xCoordinate - 1 + i][yCoordinate - 1]);
            }
        }
    }

    public void changeWeaponCount(String product, int number) {
        switch (product) {
            case "mine":
                mineCount += number;
                break;
            case "antiaircraft":
                antiaircraftCount += number;
                break;
            case "airplane":
                airplaneCount += number;
                break;
            case "scanner":
                scannerCount += number;
                break;
            case "invisible":
                invisibleCount += number;
                break;
        }
    }

    public boolean allShipsNotDestroyed() {
        for (Ship ship : ships.keySet()) {
            if (!ship.isDestroyed())
                return true;
        }
        return false;
    }

    public Ship getShipContainingCell(Cell cell) {
        for (Ship ship : ships.keySet()) {
            if (ship.containsCell(cell))
                return ship;
        }
        return null;
    }

    public void destroyShipsIfBombed() {
        for (Ship ship : ships.keySet()) {
            ship.isDestroyed();
        }
    }

    public Cell[] addAntiaircraftToBoard() {
        Cell[] antiaircraftCells = new Cell[30];
        antiaircrafts.put(antiaircraftCells, true);
        return antiaircraftCells;
    }

    public Cell[] getFirstContainingAntiaircraft(int xCoordinate, int yCoordinate) {
        for (Map.Entry<Cell[], Boolean> antiaircraft : antiaircrafts.entrySet()) {
            if (antiaircraft.getValue()) {
                for (Cell cell : antiaircraft.getKey()) {
                    if (cell.getCoordinates().compareTo(("" + xCoordinate) + yCoordinate) == 0)
                        return antiaircraft.getKey();
                }
            }
        }
        return null;
    }

    public void removeAntiaircraft(Cell[] antiaircraft) {
        antiaircrafts.put(antiaircraft, false);
        for (Map.Entry<Cell[], Boolean> nextAntiaircraft : antiaircrafts.entrySet()) {
            if (nextAntiaircraft.getValue()) {
                for (Cell cell : nextAntiaircraft.getKey()) {
                    if (!cell.containsState(State.ANTIAIRCRAFT))
                        cell.addState(State.ANTIAIRCRAFT);
                }
            }
        }
    }
}
