import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;

public class Shop {
    public static Map<String, Integer> weaponsWithPrices = Map.of(
            "mine", 1,
            "antiaircraft", 30,
            "airplane", 10,
            "scanner", 9,
            "invisible", 20
    );

    private final User user;
    private final Scanner scanner;

    public Shop(User user, Scanner scanner) {
        this.user = user;
        this.scanner = scanner;
    }


    public static int priceOfWeapon(String weaponName) {
        return weaponsWithPrices.get(weaponName);
    }

    public void shopMenu() {
        String command;
        Matcher matcher;
        while (true) {
            command = scanner.nextLine();
            if ((matcher = MatcherScanner.getCommandMatcher(command, "^buy ([^ ]+) ([0-9]+)$")).find())
                buy(matcher, user);
            else if (command.matches("back"))
                break;
            else if (command.matches("show-amount"))
                System.out.println(user.getBalance());
            else if (command.matches("help"))
                System.out.println("buy [product] [number]\n" +
                        "show-amount\n" +
                        "help\n" +
                        "back");
            else
                System.out.println("invalid command");
        }
    }

    private void buy(Matcher matcher, User user) {
        String product = matcher.group(1);
        String number = matcher.group(2);
        if (!product.matches("mine") &&
                !product.matches("antiaircraft") &&
                !product.matches("airplane") &&
                !product.matches("scanner") &&
                !product.matches("invisible"))
            System.out.println("there is no product with this name");
        else if (number.matches("0"))
            System.out.println("invalid number");
        else if (!userHasEnoughMoney(product, Integer.parseInt(number)))
            System.out.println("you don't have enough money");
        else
            makeTransaction(product, Integer.parseInt(number));
    }


    private void makeTransaction(String product, int number) {
        user.increaseOrDecreaseBalance(-priceOfWeapon(product) * number);
        user.arsenal.changeWeaponCount(product, number);
    }

    private boolean userHasEnoughMoney(String product, int number) {
        return user.getBalance() >= priceOfWeapon(product) * number;
    }

}
