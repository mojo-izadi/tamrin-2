import java.util.ArrayList;

public class User {
    private static final ArrayList<User> users = new ArrayList<>();
    private final String username;
    private String password;
    private int score;
    private int wins;
    private int draws;
    private int losses;
    private int balance;
    private boolean hasForfeited;
    public Arsenal arsenal;

    public int getScore() {
        return score;
    }

    public int getWins() {
        return wins;
    }

    public int getDraws() {
        return draws;
    }

    public int getLosses() {
        return losses;
    }

    public int getBalance() {
        return balance;
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.score = 0;
        this.wins = 0;
        this.losses = 0;
        this.draws = 0;
        this.balance = 50;
        users.add(this);
        this.arsenal = new Arsenal();
        this.hasForfeited = false;
    }

    public User() {
        this.username = "~";
        this.score = -Integer.MAX_VALUE;
        this.wins = -1;
        this.draws = -1;
        this.losses = Integer.MAX_VALUE;
    }

    public static User getUserByUsername(String username) {
        for (User user : users) {
            if (user.username.compareTo(username) == 0)
                return user;
        }
        return null;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public static boolean usernameIsTaken(String username) {
        for (User user : users) {
            if (user.username.compareTo(username) == 0)
                return true;
        }
        return false;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public void deleteUser() {
        users.remove(this);
    }

    public void increaseOrDecreaseBalance(int changeInBalance) {
        this.balance += changeInBalance;
    }


    public boolean hasShipToPlace(int length) {
        return arsenal.hasShipToPlace(length);
    }

    public void changeScore(int amount) {
        score += amount;
    }


    public void gameFinished(String winState, int gameScore) {
        switch (winState) {
            case "win":
                wins++;
                changeScore(3);
                increaseOrDecreaseBalance(50 + gameScore);
                break;
            case "win by forfeit":
                wins++;
                changeScore(2);
                increaseOrDecreaseBalance(gameScore);
                break;
            case "lose":
                losses++;
                changeScore(0);
                increaseOrDecreaseBalance(gameScore);
                break;
            case "forfeit":
                losses++;
                changeScore(-1);
                increaseOrDecreaseBalance(-50);
                break;
            case "draw":
                draws++;
                changeScore(1);
                increaseOrDecreaseBalance(25 + gameScore);
                break;
        }
        arsenal.resetShips();
        hasForfeited = false;
    }

    public boolean hasForfeited() {
        return hasForfeited;
    }

    public void setHasForfeited(boolean hasForfeited) {
        this.hasForfeited = hasForfeited;
    }
}
