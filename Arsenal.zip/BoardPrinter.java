public class BoardPrinter {

    public static void printOwnBoard(Cell[][] board) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print("|" + board[j][i].toStringForOwnBoard());
            }
            System.out.println("|");
        }
    }

    public static void printRivalBoard(Cell[][] board) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print("|" + board[j][i].toStringForRivalBoard());
            }
            System.out.println("|");
        }
    }

}
