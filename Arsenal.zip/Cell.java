import java.util.ArrayList;

public class Cell {
    private final ArrayList<State> states = new ArrayList<>();
    private static final ArrayList<Cell> cells = new ArrayList<>();
    private final int xCoordinate;
    private final int yCoordinate;


    public Cell(int xCoordinate, int yCoordinate) {
        this.states.add(State.EMPTY);
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        cells.add(this);
    }

    public String getCoordinates() {
        return ("" + xCoordinate) + yCoordinate;
    }

    public void addState(State state) {
        if (!state.equals(State.BOMBED))
            this.states.remove(State.EMPTY);
        this.states.add(state);
    }

    public boolean containsShip() {
        return (containsState(State.SHIP_WITH_LENGTH_1) ||
                containsState(State.SHIP_WITH_LENGTH_2) ||
                containsState(State.SHIP_WITH_LENGTH_3) ||
                containsState(State.SHIP_WITH_LENGTH_4));
    }

    public String toStringForOwnBoard() {
        if (states.contains(State.MINE) && states.contains(State.BOMBED))
            return "MX";
        else if (states.contains(State.MINE))
            return "Mm";
        else if (containsShip())
            return ownShipToString();
        else if (states.contains(State.BOMBED))
            return "XX";
        else if (states.contains(State.ANTIAIRCRAFT))
            return "AA";
        else
            return "  ";
    }

    public String toStringForScanner() {
        if (!containsState(State.BOMBED) && containsShip() && !containsState(State.INVISIBLE))
            return "SX";
        else
            return "  ";
    }

    public String toStringForRivalBoard() {
        if (!containsState(State.BOMBED))
            return "  ";
        else if (containsState(State.MINE))
            return "MX";
        else if (containsShip())
            return rivalShipToString();
        else
            return "XX";

    }

    private String rivalShipToString() {
        String number;
        if (!containsState(State.DESTROYED_SHIP))
            number = "X";
        else if (containsState(State.SHIP_WITH_LENGTH_1))
            number = "1";
        else if (containsState(State.SHIP_WITH_LENGTH_2))
            number = "2";
        else if (containsState(State.SHIP_WITH_LENGTH_3))
            number = "3";
        else
            number = "4";
        return "D" + number;
    }

    private String ownShipToString() {
        String number = "", shipCellState;
        if (containsState(State.SHIP_WITH_LENGTH_1))
            number = "1";
        else if (containsState(State.SHIP_WITH_LENGTH_2))
            number = "2";
        else if (containsState(State.SHIP_WITH_LENGTH_3))
            number = "3";
        else if (containsState(State.SHIP_WITH_LENGTH_4))
            number = "4";

        if (containsState(State.BOMBED))
            shipCellState = "D";
        else if (containsState(State.INVISIBLE))
            shipCellState = "I";
        else
            shipCellState = "S";

        return shipCellState + number;
    }

    public boolean containsState(State state) {
        return states.contains(state);
    }

    public boolean cannotPlaceShipOrMine() {
        return (containsShip() || containsState(State.MINE));
    }

    public void removeState(State state) {
        states.remove(state);
    }
}
